package com.altnoir.mia.component;

import net.minecraft.world.food.FoodProperties;

public class MiaFoods {
    public static final FoodProperties MISTFUZZ_PEACH = new FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).build();
}
